"use client";

export default function Settings() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Inställningar</h1>
      <p className="text-gray-600">Här kan du ändra din profil och kontoinställningar.</p>
    </div>
  );
}
